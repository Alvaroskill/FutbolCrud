El proyecto de CRUD se basará en la gestión de la base de datos de equipos de futbol.
<img src="imagenes/1.png">
<img src="imagenes/2.png">
<img src="imagenes/3.png">
<img src="imagenes/4.png">
<img src="imagenes/5.png">
<img src="imagenes/6.png">
<img src="imagenes/7.png">
<img src="imagenes/8.png">
<img src="imagenes/9.png">
<img src="imagenes/10.png">
<img src="imagenes/11.png">
<img src="imagenes/12.png">
<img src="imagenes/13.png">
